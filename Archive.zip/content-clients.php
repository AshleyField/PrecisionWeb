<div class="col-4-item">
	<div class="client-logo">
		<a href="<?php the_field('client_website'); ?>">
			<img src="<?php the_field('image'); ?>" alt="">
		</a>
	</div>
</div>